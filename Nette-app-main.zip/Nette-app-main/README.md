# Nette-app
https://moodle.spsejecna.cz/mod/assign/view.php?id=11761

Naprogramujte obdobu aplikace Doodle. Každý zaregistrovaný uživatel může vypsat termíny akce a ty se rozešlou jeho přátelům, kteří hlasují. Umožněte jim i změnu svého rozhodnutí.
